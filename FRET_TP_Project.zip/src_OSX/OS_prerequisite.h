# define _OSX

#ifdef _WINDOWS
  #include <Windows.h>
  #include <process.h>
#endif

#ifdef _OSX 
  #include <unistd.h>
  #include <pthread.h>
  #ifndef __stdcall
    #define __stdcall
  #endif
#endif

#ifndef _OS_PREREQUISITE_H
#define _OS_PREREQUISITE_H
#endif
