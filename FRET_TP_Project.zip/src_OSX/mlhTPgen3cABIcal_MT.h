// #include <Windows.h>
// #include <process.h>
#include "OS_prerequisite.h"
#include <stdlib.h>

// The following lines must be located BEFORE '#include <mex.h>'
#ifdef _MSC_VER
#define DLL_EXPORT_SYM __declspec(dllexport)
#else
#define DLL_EXPORT_SYM
#endif

#include <mex.h>
#include <matrix.h>
#include <math.h>
#include "include_gsl.h"
// #include <gsl/gsl_blas.h>
// #include <gsl/gsl_matrix.h>
// #include <gsl/gsl_vector.h>
// #include <gsl/gsl_multimin.h>
// #include <gsl/gsl_eigen.h.>
// #include <gsl/gsl_complex.h>
// #include <gsl/gsl_complex_math.h>
// #include <gsl/gsl_linalg.h>

/*
#if !defined cudaCheck
//CUDA error check from http://stackoverflow.com/a/14038590
#define cudaCheck(ans) { gpuAssert((ans), __FILE__, __LINE__); }
inline void gpuAssert(cudaError_t code, const char *file, int line, bool abort = true)
{
	if (code != cudaSuccess)
	{
		fprintf(stderr, "GPUassert: %s %s %d\n", cudaGetErrorString(code), file, line);
		if (abort) exit(code);
	}
};
#endif
*/

//#define _MLH_CUDA  // for CUDA
#define _MLH_MT  //for CPU multithreading

/* global variables for multithreading */
#ifdef _MLH_MT
  #ifdef _WINDOWS
    const size_t maxThread = 12;
    volatile double gProbeone[maxThread];
    volatile HANDLE Threads[maxThread];
    unsigned int threadIDs[maxThread];
  #endif
  #ifdef _OSX
    const size_t maxThread = 12;
    volatile double gProbeone[maxThread];
    pthread_t Threads[maxThread];
    unsigned int threadIDs[maxThread];
  #endif
#endif

/*
For 4-state (2-state (f u) X blinking (b d))

initparams=[Ef EU Ed kf+ku kb+kd kf/(kf+ku) kb/(kb+kd)];
K=[-kU-kd	kF		kb		0;
kU		-kF-kd	0		kb;
kd		0		-kU-kb	kf;
0		kd		kU		-kF-kb];
pb=kb/(kb+kd);
pf=kf/(kf+ku);
peq=[pb*pf;
pb(1-pf)
(1-pb)pf
(1-pb)(1-pf)];

resparams=mlhrateeigC(initparams,LUbounds,burstbint3r,cumindex,indexone);
*/

/* For later use. Maybe?

// mxArray structure of input variables
typedef struct _M_DATA {
const mxArray *initparams_m, *LUbounds_m, *frburstdata_m, *cumindex_m, *indexone_m;
} m_data;

// convert matlab array to gsl_matrix
void matlab_to_gsl(gsl_matrix *gsl_m,const mxArray *matlab_m)
{
double * matlab_double=mxGetPr(matlab_m);
gsl_matrix_view matalb_view=gsl_matrix_view_array(matlab_double,mxGetN(matlab_m),mxGetM(matlab_m));
gsl_matrix_transpose_memcpy(gsl_m,&matalb_view.matrix);
return;
}
*/

// C data structure of input variables 
typedef struct _C_DATA {
	double *initparams, *LUbounds, *frburstdata, *cumindex, *indexone, *E, *params, *cntrate, *ratemat0in, *statevec;

	mwSize number_of_parameters;
	mwSize number_of_states;
	mwSize number_of_colors;
	mwSize cumindex_len;
	mwSize indexone_len;
	mwSize frburst_len_m;
	mwSize frburst_len_n;

	mwSize number_of_evaluations;

	gsl_vector *L_bound;
	gsl_vector *U_bound;
} c_data;


/* variables for mlhratesub. It would be better to make a class... */
typedef struct _MLH_VARS {
	gsl_vector *pconv;
	gsl_vector *peq;

	gsl_matrix *ratemat0;
	gsl_eigen_nonsymmv_workspace *W;
	gsl_vector_complex *eigen_values;
	gsl_matrix_complex *eigen_mat;
	gsl_matrix_complex *inv_eigen_mat;

	//FRET matrix
	gsl_matrix_complex **Emat;
	gsl_matrix_complex **Emat_diag;

	// MLE cursor vector, probone
	gsl_vector_complex *probonesub;
	gsl_vector_complex *probonesub_t;
	//rate matrix variables
	gsl_matrix_complex *ratemat;
	gsl_matrix_complex *ratemat_x_E;
	gsl_vector_complex_view ratemat_diag_view;

	int nDevices, blockSize;
//	dim3 *grid;
//	dim3 block;

//	cudaStream_t* streams;

	double ** logpArray;
	double ** subMatArray;
	double ** cumindex;
	double ** indexone;
	double ** frburstdata;

	double ** rateeig;
	double * h_rateeig;

	double **d_Emat;
	double *h_Emat;

	double **d_peq;
	double *h_peq;

	double **eigenmat;
	double *h_eigenmat;

	double **inveigenmat;
	double *h_inveigenmat;

	double**expRatemat;
	double**kXE;
	double**subMat;
	double**subMatTemp;

	double* proboneT;

#ifdef _MLH_CUDA
	gsl_matrix_complex ***h_Emat_diag;
	gsl_matrix_complex **h_eigen_mat;
	gsl_matrix_complex **h_inv_eigen_mat;
	gsl_vector_complex **h_eigen_values;
	gsl_vector ** h_peqS;
#endif
} mlh_vars;

typedef struct _MLH_MT_VARS {
	gsl_vector * param;
	mlh_vars * m_vars;
	unsigned curThread;
	c_data *input_data;
	double probeone;
} mt_vars;

typedef struct _MLH_PARAM_PACK {
	c_data *data;
	mlh_vars *vars;
} mlh_param_pack;

/* Main routines */
bool input_from_matlab(const mxArray *prhs[], c_data *input_data); // Initialize input data using MATLAB input
double mlhratesub(const gsl_vector * param, void * c_data); 		// Return MLE for the given parammeter and c_data. The function to be minimized.
gsl_vector *calc_mlh(c_data *input_data); 							// Find maximum-likelihood parameter
gsl_vector *calc_mlh_sub(c_data *input_data);	// for error calc.
bool output_to_matlab(gsl_vector *output_data, mxArray *prls[]);		// Relay the parameter to MATLAB

/* mlhratesub sub-routines */
bool init_mlh_vars(mlh_vars *var, const c_data *input_data);	//dynamics allocation of mlh_vars
bool free_mlh_vars(mlh_vars *var, const c_data *input_data);

/* Customization starts */
bool ratemat0_init(gsl_matrix *ratemat0, const double *pF, const double *pB, const double *ratesumn, const double *ratesumB, const mwSize numSb, const mwSize numAcc);
bool ratemat2st_init(gsl_matrix *ratemat0, const gsl_vector *peq, const double ratesum);
/* Customization ends */

int LUbound_conv(const gsl_vector * param, const c_data *input_data, gsl_vector *pconv); 		//convert unbound param to bound pconv
int LUbound_invconv(const gsl_vector * param, const c_data *input_data, gsl_vector *pconv); 	//convert bound param to unbound pconv

/* GSL utililties */
int gsl_linalg_inv(const gsl_matrix_complex * A, gsl_matrix_complex *  inv_A); //calculate inverse matrix of A using LU decomposition
gsl_complex gsl_r2c(double r);	//convert real variable r to complex variable r+0i
double gsl_vector_complex_norm(gsl_vector_complex *v);	//calculate norm of vector v
double gsl_vector_complex_sum(gsl_vector_complex *v);	//summate absolute value of each element of v

/* Destructor */
bool input_data_free(c_data * input_data);	// free input_data

#ifdef _MLH_CUDA
											/* CUDA kernels */
__global__ void calcProbeoneSubMatrix(double *logpArray, double *subMatArray, double *cumindex, double *indexone, double *frburstdata, \
	double *rateeig, double *Emat, double *peq, mwSize numS, int molOffset, mwSize frburst_len_m, mwSize frburst_len_n, \
	double *expRatemat0, double *kXE0, double *subMat0, double *subMatTemp0, mwSize numC);
__global__ void calcProbeone(double *logpArray, double *subMatArray, double *cumindex, double *indexone, double *frburstdata, \
	double *rateeig, double *Emat, double *peq, mwSize numS, int molOffset, mwSize frburst_len_m, mwSize frburst_len_n, \
	double *eigenmat, double *inveigenmat, unsigned int blockSize, double *subMat0, double *subMatTemp0, mwSize numC);
__device__ void cudaMatrixAxB(double *A, double *B, double *C, const size_t m, const size_t l, const size_t n);
__device__ double roughNorm(double *A, const size_t m, const size_t n);

double calcProbeoneCU(mlh_param_pack *m_pack);
#endif

// CPU MT
#ifdef _WINDOWS
unsigned __stdcall analysisThread(void *param);
#endif
#ifdef _OSX
void *analysisThread(void *param);
#endif
