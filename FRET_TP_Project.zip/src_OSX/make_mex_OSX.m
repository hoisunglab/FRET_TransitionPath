% This script is used for automatically compile relevant mex routines for
% Mac platform for now 
%
% Dec. 18, 2025
% Chi-Jui Feng

%% Compile
make_command = 'mlhTPgen3cAlexABIcal_MT'; 
% Possible make_commands:
% 'mlhTPABIcal_MT', 'mlhTPgenABIcal_MT', 'mlhTPgen3cABIcal_MT', ...
% 'mlhTPgen3cAlexABIcal_MT', 'all', or 'clean'.
OSXarchitecture = 'arm64'; % 'arm64' or 'intel'
change_libgsl_path = false; % Only used when libgsl was installed other than the default path.

% CXX flags
switch OSXarchitecture
    case 'arm64'
        CXXFLAGS = "CXXFLAGS=-pthread -std=c++11 -arch arm64 -mmacosx-version-min=10.15";
    case 'intel'
        CXXFLAGS = "CXXFLAGS=-pthread -std=c++11 -arch x86_64 -mmacosx-version-min=10.15";
end

% Relevant paths of gsl library
switch OSXarchitecture
    case 'arm64'
        LDFLAGS = "LDFLAGS=$LDFLAGS -t ${YOUR_OWN_GSL_DYLIB_PATH}"; % Dynamic library path
        LIBPATH = '-I"${GSL_LIB_PATH}"'; % GSL library path
        INCPATH = '-I"${GSL_INCLUDE_PATH}"';

        srcpath = pwd; % sourch path: this folder
        mexpath = '../mex'; % Output mex folder

        default_lib_path = '/usr/local/lib/libgsl.27.dylib';
        user_lib_path = '${YOUR_OWN_GSL_DYLIB_PATH}'; % Dynamic library path
    case 'intel'
        LDFLAGS = "LDFLAGS=$LDFLAGS -t ${YOUR_OWN_GSL_DYLIB_PATH}"; % Dynamic library path
        LIBPATH = '-I"${GSL_LIB_PATH}"'; % GSL library path
        INCPATH = '-I"${GSL_INCLUDE_PATH}"';

        srcpath = pwd; % sourch path: this folder
        mexpath = '../mex'; % Output mex folder

        default_lib_path = '/usr/local/lib/libgsl.27.dylib';
        user_lib_path = '${YOUR_OWN_GSL_DYLIB_PATH}'; % Dynamic library path
end

make_obj_list = {'mlhTPABIcal_MT'; ...
    'mlhTPgenABIcal_MT'; ...
    'mlhTPgen3cABIcal_MT'; ...
    'mlhTPgen3cAlexABIcal_MT'};

cppnm = make_obj_list;
for n = 1:length(cppnm)
    cppnm{n} = [srcpath '/' cppnm{n} '.cpp'];
end

Outputnm = make_obj_list;
switch OSXarchitecture
    case 'arm64'
        for n = 1:length(Outputnm)
            Outputnm{n} = [mexpath '/' Outputnm{n} '.mexmaca64'];
        end
    case 'intel'
        for n = 1:length(Outputnm)
            Outputnm{n} = [mexpath '/' Outputnm{n} '.mexmaci64'];
        end
end

%% Check the compling list
if length(make_obj_list) ~= length(cppnm)
    error('The length of make_obj_list is different from the length of cppnm.');
end

if length(make_obj_list) ~= length(Outputnm)
    error('The length of make_obj_list is different from the length of Outputnm.');
end

%% Compiling mex and link library
switch make_command
    case 'all'
        for n = 1:length(cppnm)
            mex(cppnm{n}, '-output', Outputnm{n}, CXXFLAGS, LDFLAGS, INCPATH, LIBPATH);
        end
        if change_libgsl_path
            for n = 1:length(Outputnm)
                fprintf('Change the library of %s\n', Outputnm{n});
                cmd = sprintf('install_name_tool -change %s %s %s', ...
                    default_lib_path, user_lib_path, Outputnm{n});
                system(cmd);
            end
        end
    case 'clean'
        for n = 1:length(Outputnm)
            if exist(Outputnm{n}, 'file')
                fprintf('Cleaning %s\n', Outputnm{n})
                delete(Outputnm{n});
            end
        end
    otherwise
        mex_flag = 0;
        for n = 1:length(make_obj_list)
            if strcmp(make_command, make_obj_list{n})
                mex(cppnm{n}, '-output', Outputnm{n}, CXXFLAGS, LDFLAGS, INCPATH, LIBPATH);

                if change_libgsl_path
                    fprintf('Change the library of %s\n', Outputnm{n});
                    cmd = sprintf('install_name_tool -change %s %s %s', ...
                        default_lib_path, user_lib_path, Outputnm{n});
                    system(cmd)
                end
                mex_flag = 1;
                break
            end
        end
        if mex_flag == 0
            error('No existing make command found.');
        end
end