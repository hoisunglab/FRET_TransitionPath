/* Compute a likelihood value of a snigle transition path between State 1 and State 2
with an arbitrary transitoin path shape (n intermediates) (e.g., double paths) + acceptor blinking
collected using a 3-color pulsed interleaved excitation (PIE) experiment.
Optimization routine is not used.

Input parameters include: (total N = n+2 states)
parameters 1 to N: Acceptor 1 (A1) fraction by donor excitation [eps1_State1 eps1_TP(1) ~ eps1_TP(n) eps1_State2;
parameters N+1 to 2N: Acceptor 2 (A2) fraction by donor excitation [eps2_State1 eps2_TP(1) ~ eps2_TP(n) eps2_State2;
parameters 2N+1 to 3N: E12 by A1 excitation [eps2_State1 eps2_TP(1) ~ eps2_TP(n) eps2_State2;
parameters 3N+1 to 4N: E1 (A2 in dark state) [E1_State1 E1_TP(1) ~ E1_TP(n) E1_State2;
parameters 4N+1 to 5N: E2 (A1 in dark state) [E2_State1 E2_TP(1) ~ E2_TP(n) E2_State2;
Parameters 5N+1 to 5N+3: Donor leak into A1 and A2 channels, A1 leak into A2 channel
parameters 5N+4 and 5N+5: Rates from the dark to bright state of A1 and A2
parameters 5N+6 and 5N+7: Bright state populations of A1 and A2 at the reference photon count rate

The second last input argument is the rate matrix with the acceptor bright state.
The last input argument is a vector of the initial population with the acceptor bright state */

#include "mlhTPgen3cAlexABIcal_MT.h"


/* The gateway function */
//DLL_EXPORT_SYM  // for versions 2018b and earlier
MEXFUNCTION_LINKAGE // for Matlab 2019b
void mexFunction(int nlhs, mxArray *plhs[],
	int nrhs, const mxArray *prhs[])
{
	//Set higher priority to the process
	SetPriorityClass(GetCurrentProcess(), ABOVE_NORMAL_PRIORITY_CLASS);

	switch (nrhs)
	{
	case 8: //
	{
		//MATLAB variables
		c_data *input_data = new c_data;
		if (input_from_matlab(prhs, input_data)) //assign c_data using MATLAB input prhs
		{
			mexErrMsgTxt("Error: input parameters are inconsistent!");
			return;
		}

		/* Customization starts */
//		input_data->number_of_states = (input_data->number_of_parameters -1) *2 / 3;
		input_data->number_of_colors = 5;
		/* Customization ends*/

		gsl_vector * output_data;
		if (input_data->number_of_evaluations > 2)
		{
			output_data = calc_mlh_sub(input_data);
			output_to_matlab(output_data, plhs);
		}
		else
		{
			if (input_data->number_of_evaluations == 2) {
				input_data->number_of_evaluations = 1;
				output_data = calc_mlh_sub(input_data);
				output_to_matlab(output_data, plhs);
			}
			else {
				output_data = calc_mlh(input_data);
				output_to_matlab(output_data, plhs);
			}
		}

		//free variables
		input_data_free(input_data);
		gsl_vector_free(output_data);
	}break;

	default:
	{
		mexErrMsgTxt("Error: number of input args should be 8!");
	}
	}
	return;
}

/* Main routines */

bool input_from_matlab(const mxArray *prhs[], c_data *input_data)
// Initialize input data using MATLAB input
{
	input_data->initparams = mxGetPr(prhs[0]);
	input_data->LUbounds = mxGetPr(prhs[1]);
	input_data->frburstdata = mxGetPr(prhs[2]);
	input_data->cumindex = mxGetPr(prhs[3]);
	input_data->indexone = mxGetPr(prhs[4]);
	input_data->cntrate = mxGetPr(prhs[5]);
	input_data->ratemat0in = mxGetPr(prhs[6]);
	input_data->statevec = mxGetPr(prhs[7]);

	input_data->number_of_parameters = mxGetM(prhs[0]);

	/* Customization starts */
	input_data->number_of_states = 4*mxGetM(prhs[6]);
	/* Customization ends*/

	input_data->number_of_evaluations = mxGetN(prhs[0]);

	input_data->cumindex_len = mxGetNumberOfElements(prhs[3]);
	input_data->indexone_len = mxGetNumberOfElements(prhs[4]);
	input_data->frburst_len_m = mxGetM(prhs[2]);
	input_data->frburst_len_n = mxGetN(prhs[2]);

	input_data->L_bound = gsl_vector_calloc(input_data->number_of_parameters);
	input_data->U_bound = gsl_vector_calloc(input_data->number_of_parameters);

	for (mwSize i = 0; i<input_data->number_of_parameters; i++)
	{
		gsl_vector_set(input_data->L_bound, i, input_data->LUbounds[i]);
		gsl_vector_set(input_data->U_bound, i, input_data->LUbounds[input_data->number_of_parameters + i]);
	}

	/* Consistency check */
	// number_of_parameters should be consistent
	if (mxGetM(prhs[1]) != input_data->number_of_parameters)
	{
		mexPrintf("numel(LUbound)=%d, numOfParam=%d\n", mxGetM(prhs[1]), input_data->number_of_parameters);
		return true;
	}
	// A parameter should be between its LU bound
	for (size_t i = 0; i < input_data->number_of_parameters; i++)
	{
		if (input_data->initparams[i] < input_data->LUbounds[i])
		{
			mexPrintf("Param %d: %f<%f\n", i + 1, input_data->initparams[i], input_data->LUbounds[i]);
			return true;
		}
		if (input_data->LUbounds[input_data->number_of_parameters + i] < input_data->initparams[i])
		{
			mexPrintf("Param %d: %f<%f\n", i + 1, input_data->LUbounds[input_data->number_of_parameters + i], input_data->initparams[i]);
			return true;
		}

	}
	return false;
}

double mlhratesub(const gsl_vector * param, void * input_pack)
// Return MLE for the given parammeter and c_data. The function to be minimized.
{
#ifdef _MLH_MT
	mt_vars *mt_param = (mt_vars *)input_pack;
	c_data *input_data = mt_param[0].input_data;

	for (int i = 0; i < maxThread; i++)
	{
		gsl_vector_memcpy(mt_param[i].param, param);
		mt_param[i].curThread = i;
		Threads[i] = (HANDLE)_beginthreadex(NULL, 0, &analysisThread, (void *)&mt_param[i], 0, &threadIDs[i]);
	}
	for (int i = 0; i < maxThread; i++)
	{
		WaitForSingleObject(Threads[i], INFINITE);
	}

	for (int i = 1; i < maxThread; i++) mt_param[0].probeone += mt_param[i].probeone; //sum up probeone of each thread
	return mt_param[0].probeone;
#endif

}


unsigned __stdcall analysisThread(void *param)
{
	mt_vars* mt_param = (mt_vars*)param;
	c_data *input_data = mt_param->input_data;
	mlh_vars *m_vars = mt_param->m_vars;

	int cursor = mt_param->curThread;

	//mexPrintf("Thread %d invoked\n", cursor);

	mwSize numS = input_data->number_of_states;
	mwSize numP = input_data->number_of_parameters;
	mwSize numC = input_data->number_of_colors;

	//pconv is a converted parameter from by appling LUbound
	gsl_vector *pconv = m_vars->pconv;//gsl_vector_calloc(param->size);
									  //acquire real parameter pconv from param
	LUbound_conv(mt_param->param, input_data, pconv);

	/* Customization starts */
	double *ratemat0in = input_data->ratemat0in;
	double *statevec = input_data->statevec;
	mwSize numAcc = 2;	// Number of acceptor (We may try 4-color later)
	mwSize numSb = numS / 4;
	double *eff1s1 = new double[numSb];      // 3-color apparent E1
	double *eff2s1 = new double[numSb];      // 3-color apparent E2
	double* eff12s1 = new double[numSb];      // Apparent E12 by Aex
	double *effs2 = new double[numSb];      // Apparent E1 for DA1 part (= (A1+A2)/(D+A1+A2))
	double *effs3 = new double[numSb];      // Apparent E2 for DA2 part (= A2/(D+A1+A2))
	double effD1 = gsl_vector_get(pconv, 5*numSb); // E1 of A1,A2 dark state (= A1/(A2 + A1 + D))
	double effD2 = gsl_vector_get(pconv, 5*numSb + 1); // E2 of A1,A2 dark state (= A2/(A2 + A2 + D)) (depends on the A2-protein concentration)
	double eff12ub = gsl_vector_get(pconv, 5 * numSb + 2);       // E12 of unbound state
	double eff12A1b = 0.5; // E12 for A1 dark state, Photons by Aex are ignored.
	double eff12A1A2b = 0.5; // E12 for A1 and A2 dark state, Photons by Aex are ignored.
	double kB[2]; //ktobrt, kB[0]: A1, kB[1]: A2
	double pB0[2]; // pB0=kb/(kb+kd0), pB0[0]: A1, pB0[1]: A2

	for (mwSize i = 0; i < numSb; i++) {
		eff1s1[i] = gsl_vector_get(pconv, i);
		eff2s1[i] = gsl_vector_get(pconv, i + numSb);
		eff12s1[i] = gsl_vector_get(pconv, i + 2*numSb);
		effs2[i] = gsl_vector_get(pconv, i + 3*numSb);
		effs3[i] = gsl_vector_get(pconv, i + 4*numSb);
	}

	for (mwSize i = 0; i < numAcc; i++) {
		kB[i] = gsl_vector_get(pconv, 5 * numSb + 3 + i);
		pB0[i] = gsl_vector_get(pconv, 5 * numSb + 5 + i);
	}
	/* Customization ends */

	/* Get variables from m_vars */
	gsl_vector *peq = m_vars->peq;
	gsl_matrix *ratemat0 = m_vars->ratemat0;

	// Get diagonalization workspace
	gsl_eigen_nonsymmv_workspace *W = m_vars->W;
	gsl_vector_complex *eigen_values = m_vars->eigen_values;
	gsl_matrix_complex *eigen_mat = m_vars->eigen_mat;
	gsl_matrix_complex *inv_eigen_mat = m_vars->inv_eigen_mat;

	// Get the allocated FRET matrices
	gsl_matrix_complex **Emat = m_vars->Emat;
	gsl_matrix_complex **Emat_diag = m_vars->Emat_diag;

	// MLE cursor vector, probone
	gsl_vector_complex *probonesub = m_vars->probonesub;//gsl_vector_complex_calloc(numS);
	gsl_vector_complex *probonesub_t = m_vars->probonesub_t;//gsl_vector_complex_calloc(numS);

															//data information
	double *cumindex = input_data->cumindex;
	double *indexone = input_data->indexone;
	double *frburstdata = input_data->frburstdata;
	double *cntrate = input_data->cntrate;
	mwSize frburst_len_n = input_data->frburst_len_n;
	mwSize frburst_len_m = input_data->frburst_len_m;
	mwSize indexone_len = input_data->indexone_len;

	//rate matrix variables
	gsl_matrix_complex *ratemat = m_vars->ratemat;//gsl_matrix_complex_calloc(numS,numS);
	gsl_matrix_complex *ratemat_x_E = m_vars->ratemat_x_E;//gsl_matrix_complex_calloc(numS,numS);
	gsl_vector_complex_view *ratemat_diag_view = &m_vars->ratemat_diag_view;

	//exponent for calculation of exponential of rate diagonal matrix
	gsl_complex exponent;

	mt_param->probeone = 0;
	double ratesumB[2] = { 1000, 1000 };
	double pB[2] = { 1, 1 };
	double kD[2] = { 1000, 1000 };

	double logamp = 0;
	double photon_interval = 1;
	double normprobone = 1;
	mwSize photon_color = 1;

	for (mwSize k = mt_param->curThread; k < indexone_len; k += maxThread)
	{

		/* Customization starts */
		for (mwSize i = 0; i < numAcc; i++) {
			kD[i] = kB[i] * (1 - pB0[i]) / pB0[i] * cntrate[k] / 100; // for 100 photons per ms countrate unit.
			ratesumB[i] = kB[i] + kD[i];
			pB[i] = kB[i] / ratesumB[i];
		}
		//initialize peq
		gsl_vector_set_zero(peq);
		for (mwSize i = 0; i < numSb; i++) {
			gsl_vector_set(peq, i, statevec[i] * pB[0] * pB[1]);
			gsl_vector_set(peq, numSb + i, statevec[i] * pB[0] * (1 - pB[1]));
			gsl_vector_set(peq, 2 * numSb + i, statevec[i] * (1 - pB[0]) * pB[1]);
			gsl_vector_set(peq, 3 * numSb + i, statevec[i] * (1 - pB[0]) * (1 - pB[1]));
		}

		gsl_matrix_set_zero(ratemat0);
		for (mwSize i = 0; i < numSb; i++) {
			for (mwSize j = 0; j < numSb; j++) {
				for (mwSize k = 0; k < 2 * numAcc; k++) {
					gsl_matrix_set(ratemat0, i + k*numSb, j + k*numSb, ratemat0in[j * numSb + i]);
				}
			}
		}
		for (mwSize i = 0; i < 2 * numSb; i++) {
			gsl_matrix_set(ratemat0, i, i, gsl_matrix_get(ratemat0, i, i) - kD[0]);
			gsl_matrix_set(ratemat0, i + 2 * numSb, i, gsl_matrix_get(ratemat0, i + 2 * numSb, i) + kD[0]);
			gsl_matrix_set(ratemat0, i, i + 2 * numSb, gsl_matrix_get(ratemat0, i, i + 2 * numSb) + kB[0]);
			gsl_matrix_set(ratemat0, i + 2 * numSb, i + 2 * numSb, gsl_matrix_get(ratemat0, i + 2 * numSb, i + 2 * numSb) - kB[0]);
		}
		for (mwSize i = 0; i < numSb; i++) {
			for (mwSize j = 0; j < 2; j++) {
				gsl_matrix_set(ratemat0, i + 2 * numSb*j, i + 2 * numSb*j, gsl_matrix_get(ratemat0, i + 2 * numSb*j, i + 2 * numSb*j) - kD[1]);
				gsl_matrix_set(ratemat0, i + numSb + 2 * numSb*j, i + 2 * numSb*j, gsl_matrix_get(ratemat0, i + numSb + 2 * numSb*j, i + 2 * numSb*j) + kD[1]);
				gsl_matrix_set(ratemat0, i + 2 * numSb*j, i + numSb + 2 * numSb*j, gsl_matrix_get(ratemat0, i + 2 * numSb*j, i + numSb + 2 * numSb*j) + kB[1]);
				gsl_matrix_set(ratemat0, i + numSb + 2 * numSb*j, i + numSb + 2 * numSb*j, gsl_matrix_get(ratemat0, i + numSb + 2 * numSb*j, i + numSb + 2 * numSb*j) - kB[1]);
			}
		}
		/* Customization ends */

		//Do diagonalization
		gsl_eigen_nonsymmv(ratemat0, eigen_values, eigen_mat, W); // get eigen values and eigen vector matrix
		gsl_linalg_inv(eigen_mat, inv_eigen_mat); // get inverse of the eigen vector matrix

												  // Set FRET matrix
		for (mwSize i = 0; i < numC; i++)
		{
			gsl_matrix_complex_set_zero(Emat[i]);
			gsl_matrix_complex_set_zero(Emat_diag[i]);
		}

		/* Customization starts */
		for (mwSize i = 0; i < numSb; i++) {
			gsl_matrix_complex_set(Emat_diag[0], i, i, gsl_r2c(eff2s1[i]));
			gsl_matrix_complex_set(Emat_diag[1], i, i, gsl_r2c(eff1s1[i]));
			gsl_matrix_complex_set(Emat_diag[2], i, i, gsl_r2c(1 - eff1s1[i] - eff2s1[i]));
			gsl_matrix_complex_set(Emat_diag[3], i, i, gsl_r2c(eff12s1[i]));
			gsl_matrix_complex_set(Emat_diag[4], i, i, gsl_r2c(1 - eff12s1[i]));

			gsl_matrix_complex_set(Emat_diag[0], numSb + i, numSb + i, gsl_r2c(effs2[i] * eff12ub));
			gsl_matrix_complex_set(Emat_diag[1], numSb + i, numSb + i, gsl_r2c(effs2[i] * (1 - eff12ub)));
			gsl_matrix_complex_set(Emat_diag[2], numSb + i, numSb + i, gsl_r2c(1 - effs2[i]));
			gsl_matrix_complex_set(Emat_diag[3], numSb + i, numSb + i, gsl_r2c(eff12ub));
			gsl_matrix_complex_set(Emat_diag[4], numSb + i, numSb + i, gsl_r2c(1 - eff12ub));

			gsl_matrix_complex_set(Emat_diag[0], 2 * numSb + i, 2 * numSb + i, gsl_r2c(effs3[i]));
			gsl_matrix_complex_set(Emat_diag[1], 2 * numSb + i, 2 * numSb + i, gsl_r2c(effD1*(1 - effs3[i])));
			gsl_matrix_complex_set(Emat_diag[2], 2 * numSb + i, 2 * numSb + i, gsl_r2c((1 - effD1)*(1 - effs3[i])));
			gsl_matrix_complex_set(Emat_diag[3], 2 * numSb + i, 2 * numSb + i, gsl_r2c(eff12A1b));
			gsl_matrix_complex_set(Emat_diag[4], 2 * numSb + i, 2 * numSb + i, gsl_r2c(1 - eff12A1b));

			gsl_matrix_complex_set(Emat_diag[0], 3 * numSb + i, 3 * numSb + i, gsl_r2c(effD2));
			gsl_matrix_complex_set(Emat_diag[1], 3 * numSb + i, 3 * numSb + i, gsl_r2c(effD1));
			gsl_matrix_complex_set(Emat_diag[2], 3 * numSb + i, 3 * numSb + i, gsl_r2c(1 - effD1 - effD2));
			gsl_matrix_complex_set(Emat_diag[3], 3 * numSb + i, 3 * numSb + i, gsl_r2c(eff12A1A2b));
			gsl_matrix_complex_set(Emat_diag[4], 3 * numSb + i, 3 * numSb + i, gsl_r2c(1 - eff12A1A2b));
		}
		/* Customization ends */

		//change to eigenspace coordinate
		for (mwSize i = 0; i < numC; i++)
		{
			gsl_blas_zgemm(CblasNoTrans, CblasNoTrans, GSL_COMPLEX_ONE, Emat_diag[i], eigen_mat, GSL_COMPLEX_ZERO, Emat[i]);
			gsl_blas_zgemm(CblasNoTrans, CblasNoTrans, GSL_COMPLEX_ONE, inv_eigen_mat, Emat[i], GSL_COMPLEX_ZERO, Emat_diag[i]);
		}

		for (mwSize i = 0; i < numSb; i++)
		{
			gsl_vector_complex_set(probonesub, i, gsl_r2c(statevec[numSb + i] * pB[0] * pB[1]));
			gsl_vector_complex_set(probonesub, i + numSb, gsl_r2c(statevec[numSb + i] * pB[0] * (1 - pB[1])));
			gsl_vector_complex_set(probonesub, i + 2*numSb, gsl_r2c(statevec[numSb + i] * (1 - pB[0]) * pB[1]));
			gsl_vector_complex_set(probonesub, i + 3*numSb, gsl_r2c(statevec[numSb + i] * (1 - pB[0]) * (1 - pB[1])));
		}
		gsl_blas_zgemv(CblasNoTrans, GSL_COMPLEX_ONE, inv_eigen_mat, probonesub, GSL_COMPLEX_ZERO, probonesub_t);

		logamp = 0;

		//for burst length
		for (mwSize ii = cumindex[mwSize(indexone[k] - 1)]; ii < cumindex[mwSize(indexone[k] - 1) + 1] - 1; ii++)
		{
			photon_interval = frburstdata[frburst_len_m*(frburst_len_n - 3) + ii + 1] - frburstdata[frburst_len_m*(frburst_len_n - 3) + ii];
			photon_interval *= 1E-4; // in ms unit
			photon_color = mwSize(frburstdata[frburst_len_m*(frburst_len_n - 1) + ii]);

			//set ratemat value
			for (mwSize i = 0; i < numS; i++)
			{
				exponent = gsl_complex_exp(gsl_complex_mul_real(gsl_vector_complex_get(eigen_values, i), photon_interval));
				gsl_vector_complex_set(&ratemat_diag_view->vector, i, exponent);
			}

			//probonesub_t: previous probonesub, probonesub: new one
			gsl_blas_zgemv(CblasNoTrans, GSL_COMPLEX_ONE, Emat_diag[photon_color - 1], probonesub_t, GSL_COMPLEX_ZERO, probonesub);
			gsl_blas_zgemv(CblasNoTrans, GSL_COMPLEX_ONE, ratemat, probonesub, GSL_COMPLEX_ZERO, probonesub_t);

			if ((ii + 1) % 30 == 0)
			{
				normprobone = gsl_vector_complex_norm(probonesub_t);
				gsl_vector_complex_scale(probonesub_t, gsl_r2c(1 / normprobone));
				logamp += log(normprobone);
			}
		}
		gsl_vector_complex_memcpy(probonesub, probonesub_t);

		//the last photon color
		photon_color = frburstdata[frburst_len_m*(frburst_len_n - 1) + mwSize(cumindex[mwSize(indexone[k] - 1) + 1] - 1)];
		gsl_blas_zgemv(CblasNoTrans, GSL_COMPLEX_ONE, Emat_diag[photon_color - 1], probonesub, GSL_COMPLEX_ZERO, probonesub_t);
		gsl_blas_zgemv(CblasNoTrans, GSL_COMPLEX_ONE, eigen_mat, probonesub_t, GSL_COMPLEX_ZERO, probonesub);

		double sumtmp = 0;
		for (mwSize i = 0; i < numSb; i++) {
			for (mwSize j = 0; j < 2 * numAcc; j++) {
				sumtmp += gsl_complex_abs(gsl_vector_complex_get(probonesub, i + j * numSb)) * statevec[2 * numSb + i];
			}
		}
		mt_param->probeone += -log(sumtmp) - logamp;
	}
	//gProbeone[cursor] = probeone;
	//mexPrintf("gProbeone[%d] = %f\n", cursor, probeone);
	delete[](eff1s1);
	delete[](eff2s1);
	delete[](eff12s1);
	delete[](effs2);
	delete[](effs3);

	_endthread();
	return 0;
}

gsl_vector *calc_mlh(c_data *input_data)
// Find maximum-likelihood parameter
{
	const gsl_multimin_fminimizer_type *T =
		gsl_multimin_fminimizer_nmsimplex2;//gsl_multimin_fminimizer_nmsimplex2rand
	gsl_multimin_fminimizer *s = NULL;
	gsl_vector *ss, *x, *init_param, *output_param;
	gsl_multimin_function minex_func;

	size_t iter = 0;
	int status;
	double size;

	mlh_vars *m_vars = new mlh_vars;
	mlh_param_pack *m_pack = new mlh_param_pack;
	m_pack->data = input_data;
	m_pack->vars = m_vars;

	init_mlh_vars(m_vars, input_data);
#ifdef _MLH_MT
	mt_vars mt_param[maxThread];
	for (int i = 0; i < maxThread; i++)
	{
		mt_param[i].param = gsl_vector_calloc(input_data->number_of_parameters);
		mt_param[i].m_vars = new mlh_vars;
		mt_param[i].input_data = input_data;
		init_mlh_vars(mt_param[i].m_vars, input_data);
	}
#endif
	init_param = gsl_vector_calloc(input_data->number_of_parameters);
	output_param = gsl_vector_calloc(input_data->number_of_parameters);

	/* Starting point */
	x = gsl_vector_calloc(input_data->number_of_parameters);

	for (size_t i = 0; i<input_data->number_of_parameters; i++)
	{
		gsl_vector_set(init_param, i, input_data->initparams[i]);
	}
	LUbound_invconv(init_param, input_data, x);

	/* Set initial step sizes to 1 */
	ss = gsl_vector_calloc(input_data->number_of_parameters);
	gsl_vector_set_all(ss, 1.0);

	/* Initialize method and iterate */
	minex_func.n = input_data->number_of_parameters;
	minex_func.f = &mlhratesub;
#ifdef _MLH_MT
	minex_func.params = mt_param;
#else
	minex_func.params = m_pack;
#endif
	s = gsl_multimin_fminimizer_alloc(T, input_data->number_of_parameters);
	gsl_multimin_fminimizer_set(s, &minex_func, x, ss);

	do
	{
		iter++;
		status = gsl_multimin_fminimizer_iterate(s);

		if (status)
			break;

		size = gsl_multimin_fminimizer_size(s);
		status = gsl_multimin_test_size(size, 1e-3);

	} while (status == GSL_CONTINUE && iter < 1000);

	if (iter == 1000)
	{
		mexPrintf("Warning: 1000 interations, the minimizer terminated before converge\n");
	}

	LUbound_conv(s->x, input_data, output_param);

	gsl_vector_free(x);
	gsl_vector_free(ss);
	gsl_multimin_fminimizer_free(s);
#ifdef _MLH_MT
	for (int i = 0; i < maxThread; i++)
	{
		gsl_vector_free(mt_param[i].param);
		free_mlh_vars(mt_param[i].m_vars, input_data);
		free(mt_param[i].m_vars);
	}
#endif
	free_mlh_vars(m_vars, input_data);
	gsl_vector_free(init_param);
	delete(m_vars);
	delete(m_pack);

	//gsl_vector output_param will be freed in the main function
	return output_param;
}

gsl_vector *calc_mlh_sub(c_data *input_data)
// Return logmlh values
{
	gsl_vector *x, *init_param, *output_param;
	init_param = gsl_vector_calloc(input_data->number_of_parameters);
	x = gsl_vector_calloc(input_data->number_of_parameters);
	output_param = gsl_vector_calloc(input_data->number_of_evaluations);
	mlh_vars *m_vars = new mlh_vars;
	mlh_param_pack *m_pack = new mlh_param_pack;
	m_pack->data = input_data;
	m_pack->vars = m_vars;
	init_mlh_vars(m_vars, input_data);
#ifdef _MLH_MT
	mt_vars mt_param[maxThread];
	for (int i = 0; i < maxThread; i++)
	{
		mt_param[i].param = gsl_vector_calloc(input_data->number_of_parameters);
		mt_param[i].m_vars = new mlh_vars;
		mt_param[i].input_data = input_data;
		init_mlh_vars(mt_param[i].m_vars, input_data);
	}
#endif

#ifdef _MLH_MT
	void * input_pack = mt_param;
#else
	void * input_pack = m_pack;
#endif
	for (size_t i = 0; i<input_data->number_of_evaluations; i++)
	{
		for (size_t j = 0; j<input_data->number_of_parameters; j++) // interation on initparams
		{
			gsl_vector_set(init_param, j, input_data->initparams[i*input_data->number_of_parameters + j]);
			//mexPrintf("%f\t", input_data->initparams[i*input_data->number_of_parameters + j]);
		}
		//mexPrintf("\n");
		LUbound_invconv(init_param, input_data, x);
		gsl_vector_set(output_param, i, mlhratesub(x, input_pack)); //save mlhratesub value to output_param
	}
	free_mlh_vars(m_vars, input_data);
#ifdef _MLH_MT
	for (int i = 0; i < maxThread; i++)
	{
		gsl_vector_free(mt_param[i].param);
		free_mlh_vars(mt_param[i].m_vars, input_data);
		free(mt_param[i].m_vars);
	}
	delete(m_vars);
	delete(m_pack);
#endif
	gsl_vector_free(init_param);
	gsl_vector_free(x);

	//gsl_vector output_param will be freed in the main function
	return output_param;
}

bool output_to_matlab(gsl_vector *output_data, mxArray *plhs[])
// Relay the output parameter to MATLAB
{
	plhs[0] = mxCreateDoubleMatrix(output_data->size, 1, mxREAL);
	double * output = mxGetPr(plhs[0]);
	for (mwSize i = 0; i<output_data->size; i++)
	{
		output[i] = gsl_vector_get(output_data, i);
	}

	return true;
}


/* mlhratesub sub-routines */
bool init_mlh_vars(mlh_vars *var, const c_data *input_data)
//pre-allocate dynamic variables that repeatedly used in calc_mlh
{
	const mwSize numC = input_data->number_of_colors;
	const mwSize numS = input_data->number_of_states;
	const mwSize numP = input_data->number_of_parameters;

	//pconv is a converted parameter from by appling LUbound
	var->pconv = gsl_vector_calloc(numP);

	var->peq = gsl_vector_calloc(numS);

	var->ratemat0 = gsl_matrix_calloc(numS, numS);
	var->W = gsl_eigen_nonsymmv_alloc(numS);
	var->eigen_values = gsl_vector_complex_calloc(numS);
	var->eigen_mat = gsl_matrix_complex_calloc(numS, numS);
	var->inv_eigen_mat = gsl_matrix_complex_calloc(numS, numS);

	//FRET matrix
	var->Emat = new gsl_matrix_complex*[numS];
	var->Emat_diag = new gsl_matrix_complex*[numS];

	for (mwSize i = 0; i<numC; i++) // 0: acceptor, 1: donor
	{
		var->Emat[i] = gsl_matrix_complex_calloc(numS, numS);
		var->Emat_diag[i] = gsl_matrix_complex_calloc(numS, numS);
	}

	// MLE cursor vector, probone
	var->probonesub = gsl_vector_complex_calloc(numS);
	var->probonesub_t = gsl_vector_complex_calloc(numS);

	//rate matrix variables
	var->ratemat = gsl_matrix_complex_calloc(numS, numS);
	var->ratemat_x_E = gsl_matrix_complex_calloc(numS, numS);
	var->ratemat_diag_view = gsl_matrix_complex_diagonal(var->ratemat);

	return false;
}

bool free_mlh_vars(mlh_vars *var, const c_data *input_data)
{
	const mwSize numS = input_data->number_of_states;
	const mwSize numP = input_data->number_of_parameters;
	const mwSize numC = input_data->number_of_colors;

	//pconv is a converted parameter from by appling LUbound
	gsl_vector_free(var->pconv);
	gsl_vector_free(var->peq);

	gsl_matrix_free(var->ratemat0);
	gsl_eigen_nonsymmv_free(var->W);
	gsl_vector_complex_free(var->eigen_values);
	gsl_matrix_complex_free(var->eigen_mat);
	gsl_matrix_complex_free(var->inv_eigen_mat);

	//FRET matrix

	for (mwSize i = 0; i<numC; i++)
	{
		gsl_matrix_complex_free(var->Emat[i]);
		gsl_matrix_complex_free(var->Emat_diag[i]);
	}

	delete(var->Emat);
	delete(var->Emat_diag);

	// MLE cursor vector, probone
	gsl_vector_complex_free(var->probonesub);
	gsl_vector_complex_free(var->probonesub_t);

	//rate matrix variables
	gsl_matrix_complex_free(var->ratemat);
	gsl_matrix_complex_free(var->ratemat_x_E);

	return false;
}

/* Customization starts */
bool ratemat0_init(gsl_matrix *ratemat0, const double *pF, const double pB, const double *ratesumn, const double ratesumB, const mwSize numSb, const mwSize numAcc)
/* Customization ends */
// initialize the ratematrix using p_eq and ratesum
{
	/* Customization starts */
	double kB = ratesumB*pB;
	double kD = ratesumB*(1 - pB);
	
	gsl_matrix_set_zero(ratemat0);

	for (mwSize i = 0; i < numSb - 1; i++) {
		gsl_matrix *ratemattemp = gsl_matrix_alloc(2, 2);
		gsl_vector *peqtemp = gsl_vector_alloc(2);

		gsl_vector_set(peqtemp, 0, pF[i]);
		gsl_vector_set(peqtemp, 1, pF[i + 1]);
		gsl_vector_scale(peqtemp, 1 / (pF[i] + pF[i + 1]));
		ratemat2st_init(ratemattemp, peqtemp, ratesumn[i]);

		for (mwSize j = 0; j < 2; j++) {
			gsl_matrix_set(ratemat0, i + numSb*j, i + numSb*j, gsl_matrix_get(ratemat0, i + numSb*j, i + numSb*j) + gsl_matrix_get(ratemattemp, 0, 0));
			gsl_matrix_set(ratemat0, i + numSb*j, i + numSb*j + 1, gsl_matrix_get(ratemat0, i + numSb*j, i + numSb*j + 1) + gsl_matrix_get(ratemattemp, 0, 1));
			gsl_matrix_set(ratemat0, i + numSb*j + 1, i + numSb*j, gsl_matrix_get(ratemat0, i + numSb*j + 1, i + numSb*j) + gsl_matrix_get(ratemattemp, 1, 0));
			gsl_matrix_set(ratemat0, i + numSb*j + 1, i + numSb*j + 1, gsl_matrix_get(ratemat0, i + numSb*j + 1, i + numSb*j + 1) + gsl_matrix_get(ratemattemp, 1, 1));
		}

		gsl_matrix_free(ratemattemp);
		gsl_vector_free(peqtemp);
	}
	for (mwSize i = 0; i < numSb; i++) {
		gsl_matrix_set(ratemat0, i, i, gsl_matrix_get(ratemat0, i, i) - kD);
		gsl_matrix_set(ratemat0, i + numSb, i, gsl_matrix_get(ratemat0, i + numSb, i) + kD);
		gsl_matrix_set(ratemat0, i, i + numSb, gsl_matrix_get(ratemat0, i, i + numSb) + kB);
		gsl_matrix_set(ratemat0, i + numSb, i + numSb, gsl_matrix_get(ratemat0, i + numSb, i + numSb) - kB);
	}
	/* Customization ends */

	return false;
}

/* Customization starts */
bool ratemat2st_init(gsl_matrix *ratemat0, const gsl_vector *peq, const double ratesum)
// initialize the ratematrix using p_eq and ratesum
{
	gsl_matrix_set(ratemat0, 0, 0, -gsl_vector_get(peq, 1));
	gsl_matrix_set(ratemat0, 0, 1, gsl_vector_get(peq, 0));
	gsl_matrix_set(ratemat0, 1, 0, gsl_vector_get(peq, 1));
	gsl_matrix_set(ratemat0, 1, 1, -gsl_vector_get(peq, 0));
	gsl_matrix_scale(ratemat0, ratesum);
	return false;
}
/* Customization ends */

int LUbound_conv(const gsl_vector * param, const c_data *input_data, gsl_vector *pconv)
//convert unbound param to bound pconv
{
	gsl_vector *temp = gsl_vector_calloc(param->size);

	gsl_vector_memcpy(temp, param);
	gsl_vector_mul(temp, param); //temp=param^2
	gsl_vector_memcpy(pconv, input_data->U_bound);
	gsl_vector_sub(pconv, input_data->L_bound); //pconv=U-L
	gsl_vector_add_constant(temp, 1.0);//temp=1+param^2;
	gsl_vector_div(pconv, temp);//pconv=(U-L)/(1+param^2);
	gsl_vector_add(pconv, input_data->L_bound);//pconv=(U-L)/(1+param^2)+L;

	gsl_vector_free(temp);
	return 0;
}

int LUbound_invconv(const gsl_vector * param, const c_data *input_data, gsl_vector *pconv)
//convert bound param to unbound pconv
{
	gsl_vector *temp = gsl_vector_calloc(param->size);
	gsl_vector_memcpy(temp, param);
	gsl_vector_sub(temp, input_data->L_bound);//temp=param-L

	gsl_vector_memcpy(pconv, input_data->U_bound);
	gsl_vector_sub(pconv, input_data->L_bound);//pconv=U-L
	gsl_vector_div(pconv, temp);//pconv=(U-L)/(param-L);
	gsl_vector_add_constant(pconv, -1);//pconv=(U-L)/(param-L)-1
	for (int i = 0; i<param->size; i++)
	{
		gsl_vector_set(pconv, i, sqrt(gsl_vector_get(pconv, i)));
	}
	gsl_vector_free(temp);
	return 0;
}

/* GSL utililties */
int gsl_linalg_inv(const gsl_matrix_complex * A, gsl_matrix_complex *  inv_A)
//calculate inverse matrix of A using LU decomposition
{
	gsl_matrix_complex *A_copy = gsl_matrix_complex_calloc(A->size1, A->size2);
	gsl_matrix_complex_memcpy(A_copy, A);
	gsl_permutation *p = gsl_permutation_calloc(A->size1);
	int signum = 0;
	gsl_linalg_complex_LU_decomp(A_copy, p, &signum);
	gsl_linalg_complex_LU_invert(A_copy, p, inv_A);

	gsl_matrix_complex_free(A_copy);
	gsl_permutation_free(p);
	return 0;
}

gsl_complex gsl_r2c(double r)
//convert real variable r to complex variable r+0i
{
	gsl_complex c;
	GSL_SET_COMPLEX(&c, r, 0);
	return c;
}


double gsl_vector_complex_norm(gsl_vector_complex *v)
//calculate norm of vector v
{
	double norm_square = 0;
	for (mwSize i = 0; i<v->size; i++)
	{
		norm_square += gsl_complex_abs2(gsl_vector_complex_get(v, i));
	}
	return sqrt(norm_square);
}

double gsl_vector_complex_sum(gsl_vector_complex *v)
//summate absolute value of all element of v
{
	double sum = 0;
	for (mwSize i = 0; i<v->size; i++)
	{
		sum += gsl_complex_abs(gsl_vector_complex_get(v, i));
	}
	return sum;
}

/* Destructor */

bool input_data_free(c_data * input_data)
// free input_data
{
	gsl_vector_free(input_data->L_bound);
	gsl_vector_free(input_data->U_bound);
	delete(input_data);
	return true;
}
