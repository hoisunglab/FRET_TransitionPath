#include <Windows.h>
#include <process.h>
#include <stdlib.h>

// The following lines must be located BEFORE '#include <mex.h>'
#ifdef _MSC_VER
#define DLL_EXPORT_SYM __declspec(dllexport)
#else
#define DLL_EXPORT_SYM
#endif

#define MW_NEEDS_VERSION_H // Needed for Matlab 2019b

#include <mex.h>
#include <matrix.h>
#include <math.h>
#include <gsl/gsl_blas.h>
#include <gsl/gsl_matrix.h>
#include <gsl/gsl_vector.h>
#include <gsl/gsl_multimin.h>
#include <gsl/gsl_eigen.h.>
#include <gsl/gsl_complex.h>
#include <gsl/gsl_complex_math.h>
#include <gsl/gsl_linalg.h>

#define _MLH_MT  //for CPU multithreading

/* global variables for multithreading */
#ifdef _MLH_MT
const size_t maxThread = 24;
volatile double gProbeone[maxThread];
volatile HANDLE Threads[maxThread];
unsigned int threadIDs[maxThread];
#endif

// C data structure of input variables 
typedef struct _C_DATA {
	double *initparams, *LUbounds, *frburstdata, *cumindex, *indexone, *E, *params, *cntrate, *stateid;

	mwSize number_of_parameters;
	mwSize number_of_states;
	mwSize number_of_colors;
	mwSize cumindex_len;
	mwSize indexone_len;
	mwSize frburst_len_m;
	mwSize frburst_len_n;

	mwSize number_of_evaluations;

	gsl_vector *L_bound;
	gsl_vector *U_bound;
} c_data;


/* variables for mlhratesub. It would be better to make a class... */
typedef struct _MLH_VARS {
	gsl_vector *pconv;
	gsl_vector *peq;

	gsl_matrix *ratemat0;
	gsl_eigen_nonsymmv_workspace *W;
	gsl_vector_complex *eigen_values;
	gsl_matrix_complex *eigen_mat;
	gsl_matrix_complex *inv_eigen_mat;

	//FRET matrix
	gsl_matrix_complex **Emat;
	gsl_matrix_complex **Emat_diag;

	// MLE cursor vector, probone
	gsl_vector_complex *probonesub;
	gsl_vector_complex *probonesub_t;
	//rate matrix variables
	gsl_matrix_complex *ratemat;
	gsl_matrix_complex *ratemat_x_E;
	gsl_vector_complex_view ratemat_diag_view;

	int nDevices, blockSize;

	double ** logpArray;
	double ** subMatArray;
	double ** cumindex;
	double ** indexone;
	double ** frburstdata;

	double ** rateeig;
	double * h_rateeig;

	double **d_Emat;
	double *h_Emat;

	double **d_peq;
	double *h_peq;

	double **eigenmat;
	double *h_eigenmat;

	double **inveigenmat;
	double *h_inveigenmat;

	double**expRatemat;
	double**kXE;
	double**subMat;
	double**subMatTemp;

	double* proboneT;
} mlh_vars;

typedef struct _MLH_MT_VARS {
	gsl_vector * param;
	mlh_vars * m_vars;
	unsigned curThread;
	c_data *input_data;
	double probeone;
} mt_vars;

typedef struct _MLH_PARAM_PACK {
	c_data *data;
	mlh_vars *vars;
} mlh_param_pack;

/* Main routines */
bool input_from_matlab(const mxArray *prhs[], c_data *input_data); // Initialize input data using MATLAB input
bool init_mlh_vars(mlh_vars *var, const c_data *input_data);
double mlhratesub(const gsl_vector * param, void * c_data); 		// Return MLE for the given parammeter and c_data. The function to be minimized.
gsl_vector *calc_mlh(c_data *input_data); 							// Find maximum-likelihood parameter
gsl_vector *calc_mlh_sub(c_data *input_data);	// for error calc.
bool output_to_matlab(gsl_vector *output_data, mxArray *prls[]);		// Relay the parameter to MATLAB

																		/* mlhratesub sub-routines */
bool init_mlh_vars(mlh_vars *var, const c_data *input_data);	//dynamics allocation of mlh_vars
bool free_mlh_vars(mlh_vars *var, const c_data *input_data);

/* Customization starts */
bool ratemat0_init(gsl_matrix *ratemat0, const double *pF, const double pB, const double *ratesumn, const double ratesumB, const mwSize numSb);
bool ratemat2st_init(gsl_matrix *ratemat0, const gsl_vector *peq, const double ratesum);
/* Customization ends */

int LUbound_conv(const gsl_vector * param, const c_data *input_data, gsl_vector *pconv); 		//convert unbound param to bound pconv
int LUbound_invconv(const gsl_vector * param, const c_data *input_data, gsl_vector *pconv); 	//convert bound param to unbound pconv

																								/* GSL utililties */
int gsl_linalg_inv(const gsl_matrix_complex * A, gsl_matrix_complex *  inv_A); //calculate inverse matrix of A using LU decomposition
gsl_complex gsl_r2c(double r);	//convert real variable r to complex variable r+0i
double gsl_vector_complex_norm(gsl_vector_complex *v);	//calculate norm of vector v
double gsl_vector_complex_sum(gsl_vector_complex *v);	//summate absolute value of each element of v

														/* Destructor */
bool input_data_free(c_data * input_data);	// free input_data

// CPU MT
unsigned __stdcall analysisThread(void *param);
